﻿namespace SkiaLiteUI;

internal class Program
{
    static void Main(string[] args)
    {
        new WinTest().Run();
    }
}
